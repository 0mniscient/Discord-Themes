using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Discord;
using Discord.Commands;

namespace DiscordBot
{
    class Omnibot
    {
        static void Main(string[] args)
        {
            new Omnibot().Start();
        }

        private DiscordClient _Client;

        public void Start()
        {
            _Client = new DiscordClient(x =>
            {
                x.AppName = "OmniBot";
                x.AppUrl = "https://github.com/Chaotiic/Discord-Themes";
                x.LogLevel = LogSeverity.Info;
                x.LogHandler = Log;
            });

            _Client.UsingCommands(x =>
            {
                x.PrefixChar = '~';
                x.AllowMentionPrefix = true;
                x.HelpMode = HelpMode.Public;
            });

            var token = "MTkwMjk5MzA3NTkxNTk4MDgy.CkSTsQ.nV20gNYL4YyjsIeTFbhBWVu6K20";

            CreateCommands();

            _Client.ExecuteAndWait(async () =>
            {
                await _Client.Connect(token);
            });
        }

        public void CreateCommands()
        {
            var cService = _Client.GetService<CommandService>();

            cService.CreateCommand("themes")
                .Description("```A Step-by-Step tutorial on how to install a theme```")
                .Do(async (e) =>
                {
                    await e.Channel.SendMessage($@"Step 1: Go to #theme-repo find one you want and click the link (Skip to step 4 if you are downloading elsewhere)
Step 2: Click the Raw Button (Only for themes hosted on Github)
Step 3: Right Click and click save as 
Step 4: Save to %appdata%\betterdiscord\themes\ make sure extension is `.theme.css`
Step 5: Go back to Discord and CTRL+R
Step 6: Open Discord Settings>BetterDiscord>Themes>Check Mark the theme");
                });

            cService.CreateCommand("plugins")
                .Description("```A Step-by-Step tutorial on how to install a plugin```")
                .Do(async (e) =>
                {
                    await e.Channel.SendMessage($@"Step 1: Go to #plugin-repo find one you want and click the link (Skip to step 4 if you are downloading elsewhere)
Step 2: Click the Raw Button (Only for plugins hosted on Github)
Step 3: Right Click and click save as 
Step 4: Save to %appdata%\betterdiscord\plugins\ make sure extension is `.plugin.css`
Step 5: Go back to Discord and CTRL+R
Step 6: Open Discord Settings>BetterDiscord>Plugins>Check Mark the plugin");
                });

            cService.CreateCommand("nosettings")
                .Description("```How to fix no settings icon because of a Theme/Plugin```")
                .Do(async (e) =>
                {
                    await e.Channel.SendMessage($@"Step 1: CTRL+,
Step 2: Disable/Remove the recently added Plugin/Theme/CSS
Step 3: CTRL+R");
                });

            cService.CreateCommand("removeghostheme")
                .Description("```How to remove a ghost theme```")
                .Do(async (e) =>
                {
                    await e.Channel.SendMessage($@"**WARNING: WILL REMOVE ALL THEMES**
Step 1: CTRL+R (Just to start clean)
Step 2: CTRL+SHIFT+I
Step 3: Click the ""Console"" tab
Step 4: Enter `bdthemes = " + "{" + "}" + ";` ");
                });

            cService.CreateCommand("badcss")
                .Description("```How to remove css from the CSS tab manueally```")
                .Do(async (e) =>
                {
                    await e.Channel.SendMessage($@"Step 1: CTRL+SHIFT+I
Step 2: Click the ""Console"" tab
Step 3: Enter `$('#customcss').empty()`");
                });

            cService.CreateCommand("nothemes")
                .Description("```Help on themes not showing up```")
                .Do(async (e) =>
                {
                    await e.Channel.SendMessage($@"Step 1: Make sure you saved the theme to %appdata%\betterdiscord\themes\
Step 2: Make sure the theme files extension has `.theme.css`
Step 3: Make sure the themes 1st line of CSS contains the META tag
Step 4: Head back to Discord and CTRL+R
Step 5: If step 3 didn't work reinstall BetterDiscord
Step 6: If step 4 didn't work please ask a theme dev or Jiiks/Pohky");
                });

            cService.CreateCommand("noplugins")
                .Description("```Help on plugins not showing up```")
                .Do(async (e) =>
                {
                    await e.Channel.SendMessage($@"Step 1: Make sure you saved the theme to %appdata%\betterdiscord\plugins\
Step 2: Make sure the theme files extension has `.plugin.js`
Step 3: Make sure the Plugins 1st line of Javascript contains the META tag
Step 4: Head back to Discord and CTRL+R
Step 5: If step 3 didn't work reinstall BetterDiscord
Step 6: If step 4 didn't work please ask a plugin dev or Jiiks/Pohky");
                });

            cService.CreateCommand("unsupportedplugin")
                .Description("```*Reasons why we cannot help you with the plugin:*```")
                .Do(async (e) =>
                {
                    await e.Channel.SendMessage($@"1. Plugin is made by Bluescream and is unsupported by our community because of his bad history it is recommended to uninstall his plugin
2. Plugin is outdated and you should ask the plugin author for an update
3. Plugin is useless since Discord has adopted the plugins functions and is now a feature of Discord itself");
                });

            cService.CreateCommand("ping")
                .Description("```returns 'pong'```")
                .Do(async (e) =>
                {
                    await e.Channel.SendMessage("pong");
                });

            // Sends a file

            //cService.CreateCommand("selfie")
            //.Description("Sends bots current avatar")
            //.Do(async (e) =>
            //{
            //await e.Channel.SendFile("Selfie.jpg");
            //await e.Channel.SendMessage("Here's my selfie :wink:");
            //});

            // User says ~Hello blah and bot says Hello blah

            //cService.CreateCommand("hello")
            //.Description("says hello to a user")
            //.Parameter("user", ParameterType.Unparsed)
            //.Do(async (e) =>
            //{
            //    var toReturn = $"Hello {e.GetArg("user")}";
            //    await e.Channel.SendMessage(toReturn);
            //});
        }

        public void Log(object sender, LogMessageEventArgs e)
        {
            Console.WriteLine($"[{e.Severity}] [{e.Source}] {e.Message}");
        }
    }
}
